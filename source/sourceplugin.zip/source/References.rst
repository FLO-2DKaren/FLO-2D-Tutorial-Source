References
==========

FLO-2D Software, 2018, *Channel Modeling Guidelines*.
Nutrioso, AZ.

Library of Congress, 2017, GeoPackage Encoding Standard (OGC), version 1.0, https://www.loc.gov/preservation/digital/formats/fdd/fdd000419.shtml.

Multi-Resolution Land Characteristics Consortium, 2011, National Land Cover Database, https://www.mrlc.gov/nlcd11_data.php.

National Oceanic and Atmospheric Administration, 2017, NOAA Atlas 14 Precipitation Frequency Estimates in GIS Compatible Format,
https://hdsc.nws.noaa.gov/hdsc/pfds/pfds_gis.html.

National Oceanic and Atmospheric Administration, 2017, NOAA NEXRAD Archive, https://www.ncdc.noaa.gov/nexradinv/.

United States Department of Agriculture, 2017, Web Soil Survey, https://websoilsurvey.sc.egov.usda.gov/App/HomePage.htm.
