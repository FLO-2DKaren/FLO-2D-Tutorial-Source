Assign Results from Points Layer
================================

This tool is used to assign water surface and depth to the grid layer.

.. image:: ../../img/No-Exchange-Channel/No003.png


Edit the dialog box as shown below and click the *Assign to selected grid field* button.

.. image:: ../../img/No-Exchange-Channel/No004.png
