Grid Info Tool
==============

This tool loads the FLO-2D Grid Info panel.

.. image:: ../img/Buttons/gridinfo.png


1. Click the icon
   and then click any grid element.

2. Or Enter a grid
   element number an click the Eye.

.. image:: ../img/Grid-Info-tool/gridinfotool2.png

