No Exchange Channel Cells
=========================

The no exchange elements can be set up for any channel left bank element.
This will prevent the channel at that location from sharing discharge with the floodplain.

.. image:: ../../img/No-Exchange-Channel/No002.png

