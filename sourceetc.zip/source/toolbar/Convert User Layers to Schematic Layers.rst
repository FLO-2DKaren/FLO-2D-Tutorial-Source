Convert User Layers to Schematic Layers
=======================================

This button may help convert user layers to schematic layers.
It’s functionality is limited to very simple projects.
Be careful when using it.
Always make a restore file.

.. image:: ../img/Convert-User-Layers-to-Schematic-Layers/Conver002.png
   

1. This button 
   will update some layers if the grid element size or project domain is updated.

2. Click the  
   Convert User Layers to Schematic Layers icon.

3. Choose the  
   layers to be updated.

4. This tool  
   will write the User Layers to Schematic Layers.

.. image:: ../img/Convert-User-Layers-to-Schematic-Layers/Conver003.png

